cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.microblink.BlinkIdScanner/www/blinkIdScanner.js",
        "id": "com.microblink.BlinkIdScanner.BlinkIdScanner",
        "pluginId": "com.microblink.BlinkIdScanner",
        "clobbers": [
            "cordova.plugins.blinkIdScanner"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{}
// BOTTOM OF METADATA
});